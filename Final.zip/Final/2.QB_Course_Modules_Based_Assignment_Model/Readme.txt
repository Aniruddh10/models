#QB_Course_Modules_Based_Assignment_Model
#Created by Aniruddh and Azeem
#Caramel IT

Main Python Code-QB_Course_Modules_Based_Assignment_Model.ipynb
Dataset of QB_Skills_Based_Test.ipynb-PYM.csv
JSON Input of QB_Skills_Based_Test.ipynb-#none
JSON Output of QB_Skills_Based_Test.ipynb-1cmb.json


#-------------------------------------------------------------------------------------------------------------------#
QB_Course_Modules_Based_Assignment_Model.ipynb(Can be converted to .py file)(Python Jupyter Notebook Used Here)-
Program for unique generation of question ids based on the subcourse code for which we have to fetch questions
Inputs-Specified in comments in code
Output-Specified in comments in code

Usual Errors encountered
Error-no_of_mcqs index is out of range
Sol-This is due to the fact that the no. of questions for that particular skill for that difficulty wont be available in the database or the skill 
name would be different than the one in the database
Error-Expected type str not list (in df_tojson) code
Sol-This is due to uneven rows in dataframe maybe.Backtrack using print statements to print the dataframes before the encountered datframe to know the problem

Important-Read the comments of the code carefully.There are some comments marked for backend and AIML team to change according to the necessry requirement
set the value=false in the comments where it is mentioned to allow unique generation of questions(make sure that there are that many questions in the database otherwise 
error would be thrown)
connection of mongodb compass to python script and fetching of database from there only instead of dataset
storage of the output files in the server dynamically instead of local machine
As code has not been extensively tested some errors may be encountered but the logic of the code is  mostly strong
Ignore the index in the output part
Future Work-Increase the difficulty of the model by a little bit dynamically
#-----------------------------------------------------------------------------------------------------------------------#
Test Data Used-None for now
Some documentation is also attached
#Default Input for now(for correct output)
coursename-frontend
subsection-1
userid-1
no_of_mcq-10
difficulty-easy

